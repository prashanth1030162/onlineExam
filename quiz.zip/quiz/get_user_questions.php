<?php 
/* database file included using include function  */

include('db_connect.php');


/* session file included using include function  */
include('session.php');

$user_id = $_SESSION['user_id'];


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}

/* start of the code for getting questions from question table */

 $test_type_hdn = $_POST['test_type_hdn'];
 
 $ques_opt =array();
 
 $ques_option =array();
  $get_ques_qry = "select q.id,q.description from question q inner join user_test_type utt on q.test_type=utt.test_type 
				  where utt.user_id='".$user_id."' and q.test_type='".$test_type_hdn."'";
				  
 $get_ques_res = mysqli_query($conn,$get_ques_qry);
 $record_count=0;
  foreach($get_ques_res as $row1=>$col)	 
 {
	    
		$record_count++;
		
		$ques_option[] = $col['description'];
		$ques_option['record_count'] = $record_count;
		 $get_options_qry = "select opt.qid as ques_id,opt.id as option_id,opt.option_values from options opt where opt.qid='".$col['id']."'";
		

		$get_options_res = mysqli_query($conn,$get_options_qry);
		 
		
		
		foreach($get_options_res as $row=>$col)
		{
			
				
				$ques_option['options'][$row1][] = $col;
				
				
		}
			
			
			
		
 }

 echo json_encode($ques_option);

/* end of the code for getting questions from question table */


?>