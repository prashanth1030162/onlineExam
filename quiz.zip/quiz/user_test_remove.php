<?php

/* session file included using include function  */

include('session.php');

/* database file included using include function  */

include('db_connect.php');

/* start of the code for user test type remove  */

$user_test_remove = $_POST['test_id'];

$delete_qry ="DELETE FROM user_test_type WHERE id='".$user_test_remove."'";
$delete_res = mysqli_query($conn,$delete_qry);
if($delete_res)
{
	echo "success";
}
else
{
	echo "Error";
}

/* end of the code for user test type remove  */

?>