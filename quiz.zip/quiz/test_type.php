<?php
/* session file included using include function  */

include('session.php');

/* database file included using include function  */

include('db_connect.php');

/* start of the code for test type insert   */

if(isset($_POST['test_name']) && !empty($_POST['test_name']))
{
	$test_name = $_POST['test_name'];
	$insert_test_qry = "INSERT INTO test_type(type)values('".$test_name."')";
	$insert_test_res = mysqli_query($conn,$insert_test_qry);
}

/* end of the code for test type insert   */


?>
<div id="usrname"><a href="http://localhost/quiz/index.php">Logout</a></div>
<style>
#usrname{
	margin-left:1100px;
	margin-top:20px;
	font-weight:bold;
	color:green;
	text-transform:uppercase;
}
</style>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
</head>
<body>

<center><h3>Test Details</h3></center>

<div class="container">
  <form method="post">
    <label for="fname">Test Name</label>
    <input type="text" id="test_name" name="test_name" placeholder="Enter Test Name" required>


    <input type="submit" name="submit" id="submit" value="Submit">
  </form>
</div>

</body>
</html>


<!-- start of the code for test details display   -->

<table style="width:100%" border="1px">
  <tr>
    <th>Sno</th>
    <th>Test Name</th> 
	<th>Remove</th>
  </tr>
  <?php 
  $test_type_qry = "select id,type from test_type";
  $test_type_res = mysqli_query($conn,$test_type_qry);
  $i=0;
  while($test_row = mysqli_fetch_array($test_type_res))
  {
	  $i++;
  ?>
  <tr>
    <td><center><?php echo $i; ?></center></td>
    <td><?php echo ucwords($test_row['type']); ?></td>
    <td><center><a style="cursor:pointer;" onclick="removeTest(<?php echo $test_row['id']; ?>);"><img height="30" width="30" src="http://localhost/quiz/images/error.png"></a></center></td>
  </tr>
  <?php 
  }
  ?>
 
</table>

<!-- end of the code for test details display   -->

<!-- start of the code for removing the test type remove  -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script type="text/javascript">

function removeTest(test_id)
{
	 
	var test_id;
	$.ajax({
		url:"test_type_remove.php",
		data:{test_id,test_id},
		method:"post",
		success:function(response)
		{
			//alert(response);
			if(response=="success")
			{
				alert("Test Removed Successfully");
				location.reload();
			}
			else
			{
				alert("Error Occured");
			}
		}
		
	});
}
</script>

<!-- end of the code for removing the test type remove  -->
