<?php 
/* database file included using include function  */

include('db_connect.php');

/* start of the code for user details insertion  */

if(isset($_POST['username']) && !empty($_POST['username']))
{

$username = $_POST['username'];

$email   = $_POST['email'];

$pwd_generate = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
$set_password = substr(str_shuffle($pwd_generate), 0,7);

$user_insert_qry = "INSERT INTO user_details(username,password,email)values('".$username."','".$set_password."','".$email."')";
$result = $conn->query($user_insert_qry);

$sql = "SELECT * FROM user_details WHERE email= '".$_POST['email']."'";
$result = $conn->query($sql);
	
$check_user = $result->num_rows;

if($check_user==1)
{
	?>
	<script type="text/javascript">
	alert("User Created Successfully And Password Sent To Email");
	</script>
	<?php 
}

if($check_user==0)
{
	?>
	<script type="text/javascript">
	alert("Error Occurred");
	</script>
	<?php 
}

/* end of the code for user details insertion  */

/* start of mail code */

/*$to = $email;
$subject = "UserName And Password For The Quiz";

$message = "
<html>
<head>
<title>User Credentials</title>
</head>
<body>
<p>UserName And Password For The Quiz</p>
<table>
<tr>
<th>UserName</th>
<th>Password</th>
</tr>
<tr>
<td>".$username."</td>
<td>".$set_password."</td>
</tr>
</table>
</body>
</html>
";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

$headers .= 'From: <webmaster@example.com>' . "\r\n";
$headers .= 'Cc: admin@example.com' . "\r\n";

mail($to,$subject,$message,$headers);*/

/* End of mail code */

}
?>

<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<div class="logout"><a href="index.php">Logout </a></div>
<form class="form-horizontal" method="POST">
  <fieldset>
    <div id="legend" class="usr">
      <legend class="">Creating User</legend>
    </div>
    <div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Username</label>
      <div class="controls">
        <input type="text" id="username" name="username" placeholder="" class="input-xlarge">
        <p class="help-block">Username can contain any letters or numbers, without spaces</p>
      </div>
    </div>
 
    <div class="control-group">
      <!-- E-mail -->
      <label class="control-label" for="email">E-mail</label>
      <div class="controls">
        <input type="text" id="email" name="email" placeholder="" class="input-xlarge">
        <p class="help-block">Please provide your E-mail</p>
      </div>
    </div>
 
   
 
    <div class="control-group">
      <!-- Button -->
      <div class="controls">
        <button type="submit" name="submit" id="submit" class="btn btn-success" onclick="return validation()">Submit</button>
      </div>
    </div>
  </fieldset>
</form>

<script type="text/javascript">
function validation()
{
	var username = $("#username").val();
	if(username=="")
	{
		alert("Please Enter The UserName");
		return false;
	}
	var email = $("#email").val();
	if(email=="")
	{
		alert("Please Enter The User Email");
		return false;
	}
}

</script>

<style>
.usr{
	padding-left:100px;
}

.logout{
	margin-left:1200px;
	margin-top:10px;
	font-weight:bold;
}
</style>
