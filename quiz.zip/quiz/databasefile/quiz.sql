-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2020 at 08:57 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(30) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `qid` int(11) NOT NULL,
  `option_values` text NOT NULL,
  `correct_option` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `qid`, `option_values`, `correct_option`) VALUES
(186, 87, 'PHP stands for Hypertext Preprocessor. It is an open source server-side scripting language which is widely used for web development', 1),
(187, 87, 'PHP stands for Hypertext Preprocessor. It is an open source server-side scripting language ', 0),
(188, 87, 'PHP stands for Hypertext Preprocessor. It is an open source server-side scripting language', 0),
(189, 87, 'None', 0),
(190, 88, 'PHP echo output one or more string. It is a language construct not a function. So the use of parentheses is not required. But if you want to pass more than one parameter to echo, the use of parentheses is required', 0),
(191, 88, 'PHP echo output one or more string. It is a language construct not a function. So the use of parentheses is not required. But if you want to pass more than one parameter to echo', 1),
(192, 88, 'PHP But if you want to pass more than one parameter to echo, the use of parentheses is required', 0),
(193, 88, 'None', 0),
(194, 89, 'PHP print output a string. It is a language construct not a function. So the use of parentheses is not required with the argument list.', 0),
(195, 89, 'PHP print output a string. It is a language construct not a function. So the use of parentheses is not required with the argument list. Unlike echo, it always returns 1.', 1),
(196, 89, 'PHP print output a string. It is a language construct not a function Unlike echo, it always returns 1.', 0),
(197, 89, 'None', 0),
(198, 90, 'A PHP variable is the name of the  data. It is temporary storage.', 0),
(199, 90, 'A PHP variable is the name of the memory location that holds data.', 0),
(200, 90, 'A PHP variable is the name of the memory location that holds data. It is temporary storage.', 1),
(201, 90, 'None', 0),
(202, 91, 'message stores variable data while $$message is used to store variable of variables.', 0),
(203, 91, '$message stores variable data while message is used to store variable of variables.', 0),
(204, 91, '$message stores variable data while $$message is used to store variable of variables.', 1),
(205, 91, 'None', 0),
(206, 92, 'For, while, do-while and for each.', 1),
(207, 92, 'For, while, do-while ', 0),
(208, 92, 'do-while and for each.', 0),
(209, 92, 'None', 0),
(210, 93, 'It means you can pass 0, 1 or n number of arguments.', 0),
(211, 93, 'PHP supports variable length argument function. ', 0),
(212, 93, 'PHP supports variable length argument function. It means you can pass 0, 1 or n number of arguments.', 1),
(213, 93, 'PHP supports variable length argument function. or n number of arguments.', 0),
(214, 94, ' In PHP, it orders maps of pairs of keys and values. It saves the collection of the data type.', 0),
(215, 94, 'An array is used to store multiple values in a single value. In PHP, it orders maps of pairs of keys and values. ', 0),
(216, 94, 'An array is used to store multiple values in a single value. In PHP, it orders maps of pairs of keys and values. It saves the collection of the data type.', 1),
(217, 94, 'None', 0),
(218, 95, 'The indexed array holds elements in an indexed form which is represented by number starting from 0 and incremented by 1.', 1),
(219, 95, 'The indexed array holds elements in an indexed form which is represented by number  For example:', 0),
(220, 95, 'The indexed array holds elements in an indexed form which is represented by number starting from 0 and incremented by 1. ', 0),
(221, 95, 'None', 0),
(222, 96, 'The strlen() function is used to get the length of the string.', 1),
(223, 96, 'The strlen function is used to get the length of the string.', 0),
(224, 96, 'The str() function is used to get the length of the string.', 0),
(225, 96, 'None', 0),
(226, 97, 'Java is a high-level programming language and is platform-dependent.', 0),
(227, 97, 'Java is a high-level programming language ', 0),
(228, 97, 'Java is a high-level programming language and is platform-independent.', 1),
(229, 97, 'None', 0),
(230, 98, 'Java It is used to convert the instructions into bytecodes', 0),
(231, 98, 'Java uses Just In Time compiler to enable high performance. It is used to convert', 0),
(232, 98, 'Java uses Just In Time compiler to enable high performance. It is used to convert the instructions into bytecodes', 1),
(233, 98, 'None', 0),
(234, 99, 'An instance of a class is called an object. ', 0),
(235, 99, 'An instance of a class is called an object. The object has state and behavior.', 1),
(236, 99, 'An instance of a class is The object has state and behavior.', 0),
(237, 99, 'None', 0),
(238, 100, 'Inheritance Encapsulation Polymorphism Abstraction Interface', 1),
(239, 100, 'Inheritance Encapsulation ', 0),
(240, 100, 'Inheritance Encapsulation Polymorphism Abstraction Interface etc', 0),
(241, 100, 'None', 0),
(242, 101, ' Inheritance means one class can extend to another class. So that the codes can be reused from one class to another class', 1),
(243, 101, ' So that the codes can be reused from one class to another class', 0),
(244, 101, ' Inheritance means one class can extend to another class.  one class to another class', 0),
(245, 101, 'None', 0),
(246, 102, 'A single object can refer to the super-class or sub-class depending on the reference type .', 0),
(247, 102, 'A single object can refer to the sub-class depending on the reference type which is called polymorphism.', 0),
(248, 102, 'A single object can refer to the super-class or sub-class depending on the reference type which is called polymorphism.', 1),
(249, 102, 'None', 0),
(250, 103, 'The key benefit of overriding is that the Sub-class can provide  about that sub-class type than the super-class.', 0),
(251, 103, 'some specific information', 0),
(252, 103, 'The key benefit of overriding is that the Sub-class can provide some specific information about that sub-class type than the super-class.', 1),
(253, 103, 'None', 0),
(254, 104, 'framework that is designed to store the objects and manipulate the design to store the objects.', 0),
(255, 104, 'Collection is a framework that is designed to store the objects to store the objects.', 0),
(256, 104, 'Collection is a framework that is designed to store the objects and manipulate the design to store the objects.', 1),
(257, 104, 'None', 0),
(258, 105, 'It So we can iterate the values from the collection in a specific order', 0),
(259, 105, 'It means the values that are stored in a collection is based on the values that are added to the collection. So we can iterate the values from the collection in a specific order', 1),
(260, 105, 'It means the values that are stored in a collection is based on the values that are added to the collection. ', 0),
(261, 105, 'None', 0),
(262, 106, 'Set cares about uniqueness. It doesnâ€™t allow duplications. Here â€œequals ( )â€ method is used to determine whether two objects are identical or not', 1),
(263, 106, 'Set cares about uniqueness. It doesnâ€™t allow duplications. Here â€œequals ( )â€ method is used to determine whether two objects are identical or not', 0),
(264, 106, 'Set cares about uniqueness. It doesnâ€™t allow duplications. method is used to determine whether two objects are identical or not', 0),
(265, 106, 'None', 0);

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `test_type` int(50) NOT NULL,
  `created_on` datetime NOT NULL,
  `created_by` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id`, `description`, `test_type`, `created_on`, `created_by`) VALUES
(87, 'What is PHP ?', 31, '0000-00-00 00:00:00', 0),
(88, 'What is "echo" in PHP?', 31, '0000-00-00 00:00:00', 0),
(89, 'What is "print" in PHP?', 31, '0000-00-00 00:00:00', 0),
(90, 'How a variable is declared in PHP?', 31, '0000-00-00 00:00:00', 0),
(91, 'What is the difference between $message and $$message?', 31, '0000-00-00 00:00:00', 0),
(92, 'What are the different loops in PHP?', 31, '0000-00-00 00:00:00', 0),
(93, 'Explain PHP variable length argument function.', 31, '0000-00-00 00:00:00', 0),
(94, 'What is the array in PHP?', 31, '0000-00-00 00:00:00', 0),
(95, 'What is the difference between indexed and associative array?', 31, '0000-00-00 00:00:00', 0),
(96, 'How to get the length of string?', 31, '0000-00-00 00:00:00', 0),
(97, 'What is JAVA?', 32, '0000-00-00 00:00:00', 0),
(98, 'How does Java enable high performance?', 32, '0000-00-00 00:00:00', 0),
(99, 'What is an Object?', 32, '0000-00-00 00:00:00', 0),
(100, 'What are the OOPs concepts?', 32, '0000-00-00 00:00:00', 0),
(101, 'What is Inheritance?', 32, '0000-00-00 00:00:00', 0),
(102, 'What is Polymorphism?', 32, '0000-00-00 00:00:00', 0),
(103, 'What is meant by Method Overriding?', 32, '0000-00-00 00:00:00', 0),
(104, 'What is mean by Collections in Java?', 32, '0000-00-00 00:00:00', 0),
(105, 'What is meant by Ordered in collections?', 32, '0000-00-00 00:00:00', 0),
(106, 'Explain about Set and their types in a collection?', 32, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `test_type`
--

CREATE TABLE `test_type` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_type`
--

INSERT INTO `test_type` (`id`, `type`) VALUES
(31, 'PHP'),
(32, 'java');

-- --------------------------------------------------------

--
-- Table structure for table `user_answers`
--

CREATE TABLE `user_answers` (
  `id` int(11) NOT NULL,
  `qid` int(50) NOT NULL,
  `opt_id` int(50) NOT NULL,
  `user_id` int(50) NOT NULL,
  `test_type` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_answers`
--

INSERT INTO `user_answers` (`id`, `qid`, `opt_id`, `user_id`, `test_type`) VALUES
(21, 87, 187, 2, 31),
(22, 88, 190, 2, 31),
(23, 89, 195, 2, 31),
(24, 90, 198, 2, 31),
(25, 91, 203, 2, 31),
(26, 92, 206, 2, 31),
(27, 93, 211, 2, 31),
(28, 94, 215, 2, 31),
(29, 95, 218, 2, 31),
(30, 96, 222, 2, 31),
(31, 97, 227, 3, 32),
(32, 98, 230, 3, 32),
(33, 99, 236, 3, 32),
(34, 100, 241, 3, 32),
(35, 101, 242, 3, 32),
(36, 102, 248, 3, 32),
(37, 103, 251, 3, 32),
(38, 104, 255, 3, 32),
(39, 105, 259, 3, 32),
(40, 106, 263, 3, 32);

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `created_on` datetime NOT NULL,
  `created_by` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `username`, `password`, `email`, `created_on`, `created_by`) VALUES
(2, 'john', '3Veq7xA', 'john@gmail.com', '0000-00-00 00:00:00', 0),
(3, 'David', 'WZveyaD', 'David@gmail.com', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_test_type`
--

CREATE TABLE `user_test_type` (
  `id` int(11) NOT NULL,
  `user_id` int(50) NOT NULL,
  `test_type` int(10) NOT NULL,
  `test_date` date NOT NULL,
  `total_time` varchar(50) NOT NULL,
  `time_taken` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_test_type`
--

INSERT INTO `user_test_type` (`id`, `user_id`, `test_type`, `test_date`, `total_time`, `time_taken`) VALUES
(68, 2, 31, '2020-06-17', '00:20:00', '00:19:30'),
(69, 3, 32, '2020-06-17', '00:20:00', '00:18:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `qid` (`qid`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_type`
--
ALTER TABLE `test_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_answers`
--
ALTER TABLE `user_answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_test_type`
--
ALTER TABLE `user_test_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=266;
--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;
--
-- AUTO_INCREMENT for table `test_type`
--
ALTER TABLE `test_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `user_answers`
--
ALTER TABLE `user_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user_test_type`
--
ALTER TABLE `user_test_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `options`
--
ALTER TABLE `options`
  ADD CONSTRAINT `options_ibfk_1` FOREIGN KEY (`qid`) REFERENCES `question` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
