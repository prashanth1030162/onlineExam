<?php
session_destroy();
header("Location: http://localhost/quiz/user_login.php"); 

?>