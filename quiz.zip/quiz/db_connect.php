<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "quiz";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}




/*$db_connect = mysqli_connect("localhost","root","");
$res =mysqli_select_db($db_connect,"quiz");
if($res)
{
	return true;
}
else
{
	return false;
}*/
?>