<?php 
/* database file included using include function  */
include('db_connect.php');

/* session file included using include function  */
include('session.php');

$user_id = $_SESSION['user_id'];

/* start of the code for user answers */

$get_answers = $_POST['sub_ques'];
$test_type_hdn = $_POST['test_type_hdn'];

 $values="";
foreach($get_answers as $get_ans)
{
	 
	
	$ques_insert_qry="insert into user_answers(qid,opt_id,user_id,test_type)values('".$get_ans['ques_id']."','".$get_ans['getopt_id']."','".$user_id."','".$test_type_hdn."')";
	mysqli_query($conn,$ques_insert_qry);
	
	
	
}

/* end of the code for user answers */

/* start of the code for test type and time updating for the quiz */

	$getminutes = $_POST['getminutes'];
	$getseconds = $_POST['getseconds'];
	$time_taken = "00:".$getminutes.":".$getseconds;

	$test_date = date("Y-m-d");
	
	$total_time="00:20:00";
	
	
	$ques_update_qry = "update user_test_type set test_date='".$test_date."',total_time='".$total_time."',time_taken='".$time_taken."' where user_id='".$user_id."'";
	mysqli_query($conn,$ques_update_qry);
	
	echo "success";
	
/* end of the code for test type and time updating for the quiz */
	


?>