<?php 
/* session file included using include function  */

include('session.php');

/* database file included using include function  */

include('db_connect.php');

?>
<div id="usrname"><a href="http://localhost/quiz/index.php">Logout</a></div>
<style>
#usrname{
	margin-left:1100px;
	margin-top:20px;
	font-weight:bold;
	color:green;
	text-transform:uppercase;
}
</style>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 50%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
</head>
<body>

<center><h3>Test Assign</h3></center>

<?php 

/* start of the code for user test type insertion */

if(isset($_POST['user_name']) && !empty($_POST['user_name']))
{
	 $assign_qry = "INSERT INTO user_test_type(user_id,test_type)values('".$_POST['user_name']."','".$_POST['test_name']."')";
	$assign_res = mysqli_query($conn,$assign_qry);
}

/* end of the code for user test type insertion */

/* start of the code for user details */

$user_qry="select id,username from user_details";
$user_res = mysqli_query($conn,$user_qry);

/* end of the code for user details */

/* start of the code for test type */

$type_qry="select id,type from test_type";
$type_res = mysqli_query($conn,$type_qry);

/* end of the code for test type */

?>
<center>
<div class="container">
  <form method="post">
    <label for="fname">User Name</label>
    
	<select required name="user_name" id="user_name">
	<option value="0"> --Select User Name--</option>
	<?php
		while($user = mysqli_fetch_array($user_res))
		{
			?>
			<option value="<?php echo $user['id']; ?>"><?php echo $user['username']; ?></option>
			<?php 
		}
			
	?>
	  
	</select>
	</div>
	<div class="container">
	<label for="fname">Test Name</label>
    
	<select required name="test_name" id="test_name">
	<option value="0"> --Select Test Name--</option>
	<?php
		while($type = mysqli_fetch_array($type_res))
		{
			?>
			<option value="<?php echo $type['id']; ?>"><?php echo $type['type']; ?></option>
			<?php 
		}
			
	?>
	  
	</select>
 </div>

    <input type="submit" name="submit" id="submit" value="Submit" onclick="return validation()"></center>
  </form>


</body>
</html>

<br/>

<!-- start of the code for user test details -->

<table style="width:100%" border="1px">
  <tr>
    <th>Sno</th>
    <th>User Name</th> 
	<th>Test Name</th> 
	<th>Remove</th>
  </tr>
  <?php 
  $test_type_qry = "select utype.id,usd.username,ttype.type from user_test_type utype inner join user_details usd ON utype.user_id=usd.id 
				    inner join test_type ttype ON ttype.id=utype.test_type";
  $test_type_res = mysqli_query($conn,$test_type_qry);
  $i=0;
  while($test_row = mysqli_fetch_array($test_type_res))
  {
	  $i++;
  ?>
  <tr>
    <td><center><?php echo $i; ?></center></td>
    <td><?php echo ucwords($test_row['username']); ?></td>
	<td><?php echo ucwords($test_row['type']); ?></td>
    <td><center><a style="cursor:pointer;" onclick="removeTest(<?php echo $test_row['id']; ?>);"><img height="30" width="30" src="http://localhost/quiz/images/error.png"></a></center></td>
  </tr>
  <?php 
  }
  ?>
 
</table>

<!-- end of the code for user test details -->


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script type="text/javascript">
function validation()
{
	
	var user_name = $("#user_name").val();
	if(user_name==0)
	{
		alert("Please Select The User Name");
		return false;
	}
	var test_name = $("#test_name").val();
	if(test_name==0)
	{
		alert("Please Select The Test Name");
		return false;
	}
}


function removeTest(test_id)
{
	 
	var test_id;
	
	$.ajax({
		url:"user_test_remove.php",
		data:{test_id,test_id},
		method:"post",
		success:function(response)
		{
			//alert(response);
			if(response=="success")
			{
				alert("Test Removed Successfully");
				location.reload();
			}
			else
			{
				alert("Error Occured");
			}
		}
		
	});
}
</script>