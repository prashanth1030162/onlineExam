<?php 

/* database file included using include function  */

include('db_connect.php');

/* start of the code questions and options insertion   */

if(isset($_POST['options']) && !empty($_POST['options']))
{
	$get_options = $_POST['options'];
}

if(isset($_POST['description']) && !empty($_POST['description']))
{

	$question_description = $_POST['description'];

}
if(isset($_POST['test_type']) && !empty($_POST['test_type']))
{

	$test_type = $_POST['test_type'];

}
if(!empty($_POST['description']) && isset($_POST['description']))
{
	$question_insert = "INSERT INTO question(description,test_type)value('".$question_description."','".$test_type."')";
	$question_result = mysqli_query($conn,$question_insert);
	$question_last_id = mysqli_insert_id($conn);
}

if(isset($_POST['option_hdn']) && !empty($_POST['option_hdn']))
{
	$option_hdn = $_POST['option_hdn'];
}
$values="";

if(!empty($get_options) && isset($get_options))
{
	foreach($get_options as $key=>$value)
	{
		
		if($option_hdn==$key)
		{
			$correct_option=1;
		}
		else
		{
			$correct_option = 0;
		}
			$value = mysqli_real_escape_string($conn,$value);
		$values.= "('".$question_last_id."','".$value."','".$correct_option."'),";
	}
}
	
	$get_values = substr($values, 0, -1);
	
	 $option_insert_qry = "INSERT INTO options(qid,option_values,correct_option)values".$get_values;
	
	mysqli_query($conn,$option_insert_qry);
	
/* end of the code questions and options insertion   */

/* start of the code for getting test type details   */

 $get_test_type_qry="select id,type from test_type";
 $test_type_res = mysqli_query($conn,$get_test_type_qry);

/* end of the code for getting test type details   */

?>

<html>
<head>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="quiz.css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>


<!-- start of the code online exam for page  -->

<form method="post">

<div class="logout"><a href="index.php">Logout </a></div>


<div class="container">
	<div class="row">
		<h2><center>Online Exam</center></h2>
	    <br/>
        <div class="panel panel-primary">
				
             <div class="panel-heading"> 
				<center><!--<div>Time: 01:20:30</div>--></center>
                  <pre><textarea cols="152" rows="12" name="description" id="description"></textarea>                   
                  </pre>
             </div><!--.panel-heading-->
        
<div class = "panel-body">
      <h4>Give Your Options And Select Any Answer.</h4>
           </div>



<div class="panel-footer">
				
				<div id="test_type">
					<select name="test_type" id="test_type">
					<option value="0">Please Select Test Type</option>
					<?php 
					
					while($test_type_row = mysqli_fetch_array($test_type_res))
					{
					
					?>
						<option value="<?php echo $test_type_row['id']; ?>"><?php echo ucwords($test_type_row['type']); ?></option>
					<?php 
					}
					?>
					
					</select>

				</div>
                    
					
					
   </div>



                <div class="panel-footer">
				
				<div id="addTextbox">
				<li>
    <input type="radio"
           name="answer"
           value="1" onclick="getOptionValue(1)" />

        <input type="text" size="90" name="options[option_value1]"  id="option_value1" />
		<input type="button" name="addmore" id="addmore" value="AddMore" onclick="addAnswer()">
</li>
	</div>
                    
					
					
                </div>
					<center> <div><input type="submit" name="submit" id="submit" value="submit" onclick="return validate()">
					 </div></center>
        </div>
		
			
</div>
</div>

<input type="hidden" name="option_hdn" id="option_hdn">

</form>

<!-- end of the code online exam for page  -->


<footer></footer>
</html>
<script type="text/javascript">
var i=1;
var opt;
function addAnswer()
{
	 i++;
	 opt = i;
	$("#addTextbox").append("<div id='option_box'><li id=option"+i+"><br/><input type='radio' name='answer' value="+opt+" onclick='getOptionValue("+opt+")'><input type='text' name='options[option_value"+opt+"]' id=option_value"+opt+" size='90' /><input type='button' name='remove' id='remove' value='Remove' onclick='removeAnswer("+i+")'></li></div>");
    opt++;
}
function removeAnswer(j)
{
	
	var j;
	$("#option"+j).remove();
}
function getOptionValue(opt_value)
{
	var opt_value;
	$("#option_hdn").val("option_value"+opt_value);
}
function validate()
{
	var description = $("#description").val();
	if(description=="")
	{
		alert("Please Enter The Question");
		return false;
	}
	var test_type = $("#test_type").val();
	if(test_type=="0")
	{
		alert("Please Select The Test Type");
		return false;
	}
	
	 var answer = document.getElementsByName('answer');
        var answerValue = false;

        for(var i=0; i<answer.length;i++){
            if(answer[i].checked == true){
                answerValue = true;    
            }
        }
        if(!answerValue){
            alert("Please Choose the Answer");
            return false;
        }
}
</script>
<style>
#test_type{
	margin-left:20px;
	width:650px;
}
#option_box{
	margin-left:20px;
}
.logout{
	margin-left:1200px;
	margin-top:10px;
	font-weight:bold;
}
</style>