<?php 
/* database file included using include function  */
include('db_connect.php');

/* session file included using include function  */

include('session.php');

if(isset($_SESSION['user_id']))
{
	$user_id = $_SESSION['user_id'];
	$user_name = $_SESSION['user_name'];
}
else
{
	$user_name="";
}

if(isset($_POST['test_type']))
{
	$test_type_hdn = $_POST['test_type'];
	$_SESSION['test_type_id'] = $test_type_hdn;
}
else
{
	$test_type_hdn="";
}
?>
<div id="usrname">Welcome <?php echo $user_name; ?></div>
<div id="usrname"><a href="http://localhost/quiz/user_logout.php">Logout</a></div>
<style>
#usrname{
	margin-left:1100px;
	margin-top:20px;
	font-weight:bold;
	color:lightblue;
	text-transform:uppercase;
}
#description {
	
	margin-top:-35px;
	margin-left:15px;
}
</style>

<!-- start of the code for displaying questions -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
var q=0;
var next_ques;
$("#submit").hide();
$("#previous").hide();
var qno=1;

var chk=1;

var checked1="";


function display_questions(ques_options,next_ques)
{
	
	
	$("#qno").html(qno);
	
	var ques_options;
		
	 var ques_options_obj = JSON.parse(ques_options);
	 
	 
	 console.log("ques_options_obj="+ques_options_obj);
	 
	var total_question = ques_options_obj.record_count;
	
	if(next_ques=="next")
	{
		
		
		qno++;
		q++;
		
		if(qno>1)
		{
			$("#previous").show();
		}
		if(q==total_question-1)
		{
			$("#next").hide();
			$("#previous").hide();
			$("#submit").show();
		}
		
		$("#qno").html(qno);
	}
	if(next_ques=="prev")
	{
		
		
		q--;
		
		if(q<=0)
		{
			q=0;
			$("#previous").hide();
		}
		
		if(qno<=1)
		{
			qno=1;
			
		}
		if(qno>1)
		{
			qno--;
		}
		$("#qno").html(qno);
		
	}
	
	 
	 
		var get_question;
	
		 get_question = ques_options_obj[q];
		 $("#description").html(get_question);
		 
		
	 var div_radio="";	 
	 for(k=0;k<ques_options_obj['options'][q].length;k++)
	 {
		 
		 
		 var get_option_id = ques_options_obj['options'][q][k].option_id;
		 var get_option_value = ques_options_obj['options'][q][k].option_values;
		 
		 var getopt_id_val = $("#opt_id"+get_option_id).val();
		 
		 if(getopt_id_val==get_option_id)
		 {
			
			  checked1='checked';
			 
		 }
		 else
		 {
			 checked1='';
		 }
		 
		 		
		 var ques_id = ques_options_obj['options'][q][k].ques_id;
		 
		 div_radio +="<div class='panel-footer'>";
				
		div_radio +="<div id='chk_box"+chk+"'>";
		div_radio += "<li><input type='radio' "+checked1+" name='user_options' id='opt_radio"+get_option_id+"' value='"+get_option_id+"' onclick='submit_questions("+ques_id+","+get_option_id+")'   > "+get_option_value+"</li>";
		div_radio +="</div>";
		div_radio +="</div>";
				
		$("#option_html").html(div_radio);
		
		 
	 }
	 
	 
	 
	
}


</script>

<!-- End of the code for displaying questions -->

    <div id="radio_chk"></div>

<!-- start of the code for online exam form page -->

<html>
<head>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="quiz.css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>

<form method="post">

<div class="container">
	<div class="row">
		<h2><center>Online Exam</center></h2>
	    <br/>
        <div class="panel panel-primary">
				
             <div class="panel-heading"> 
				<center><div>Time Remaining <span id="time">20:00</span> minutes!</div></center>
                  <pre> <div id="qno"></div> <div id="description"></div>                
                  </pre>
             </div><!--.panel-heading-->
        
<div class = "panel-body">
      <h4>Choose Any Option.</h4>
           </div>

                
				
				<div id="option_html">
				
				</div>
				
				
					<center>
				
					<div>
							<input type="button" name="previous" id="previous" value="Previous" style="display:none"; onclick="next_questions('prev')">
							
							<input type="button" name="next" id="next" value="Next" onclick="next_questions('next')">
							
							<input type="button" name="submit" id="submit" value="Submit" style="display:none"; onclick="submit_answers()";>
							
					 </div>
					 
					 </center>
        </div>
		
			
</div>
</div>

<input type="hidden" name="option_hdn" id="option_hdn">

<input type="hidden" name="ques_opt_hdn" id="ques_opt_hdn">

<input type="hidden" name="minute_hdn" id="minute_hdn">

<input type="hidden" name="seconds_hdn" id="seconds_hdn">

<input type="hidden" name="test_type_hdn" id="test_type_hdn" value="<?php echo $test_type_hdn;?>">

</form>

<footer></footer>
</html>

<!-- End of the code for online exam form page -->

<!-- start of the code for function for displaying next questions  -->

<script type="text/javascript">
var test_type_hdn;
var btn_txt="";
next_questions(btn_txt);
function next_questions(btn_txt)
{

 test_type_hdn = $("#test_type_hdn").val();
	
$.ajax({
	url:"get_user_questions.php",
	data:{test_type_hdn:test_type_hdn},
	method:"post",
	success:function(response)
	{
		if(response)
		{
			display_questions(response,btn_txt);
			return true;
		}
		else
		{
			return false;
		}
	}
});

}

<!-- End of the code for function for displaying next questions  -->

<!-- start of the code of function for submitting questions -->

var sub_ques=[];
function submit_questions(ques_id,getopt_id)
{
	var ques_id;
	var getopt_id;
	
	
	$("#radio_chk").append("<input type='hidden' id='opt_id"+getopt_id+"' value="+getopt_id+" >");
	
	if(sub_ques.length>0)
	{
		for(i=0;i<sub_ques.length;i++)
		{
			if(sub_ques[i].ques_id==ques_id)
			{
				
				$("#opt_id"+sub_ques[i].getopt_id).remove();
				delete sub_ques[i].ques_id;
				delete sub_ques[i].getopt_id;
				
				
			}
		}
	}
	
	
	
	sub_ques.push({ques_id:ques_id,getopt_id:getopt_id});
	
	
	console.log("get sub="+sub_ques);
	
}

<!-- End of the code of function for submitting questions -->


<!-- start of the code of function for submitting answers -->

function submit_answers()
{
	
	var getminutes = $("#minute_hdn").val();
	var getseconds = $("#seconds_hdn").val();
	test_type_hdn = $("#test_type_hdn").val();
	
	$.ajax({
		url:"user_answers.php",
		type:"post",
		data:{sub_ques:sub_ques,getminutes:getminutes,getseconds:getseconds,test_type_hdn:test_type_hdn},
		success:function(response)
		{
			if(response)
			{
				
				alert("Submitted Successfully");
				location.href='result_page.php';
			}
			else
			{
				alert("Error Occurred!");
			}
		}
		
	});
	
}

<!-- End of the code of function for submitting answers -->

</script>

<!-- start of the code of function for displaying timer -->

<script type="text/javascript">
 function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;
	
		$("#minute_hdn").val(minutes);
		$("#seconds_hdn").val(seconds);
		
		if(minutes==00 && seconds==00)
		{
			alert("Test Time completed");
			
			var getminutes = $("#minute_hdn").val();
			var getseconds = $("#seconds_hdn").val();
			test_type_hdn = $("#test_type_hdn").val();
			
			$.ajax({
				url:"user_answers.php",
				type:"post",
				data:{sub_ques:sub_ques,getminutes:getminutes,getseconds:getseconds,test_type_hdn:test_type_hdn},
				success:function(response)
				{
					if(response)
					{
						
						location.href='result_page.php';
					}
					else
					{
						alert("Error Occurred!");
					}
				}
				
			});
			
			
		}

        display.textContent = minutes + ":" + seconds;

        if (--timer < 0) {
            timer = duration;
        }
    }, 1000);
}

window.onload = function () {
    var fiveMinutes = 60 * 20,
        display = document.querySelector('#time');
    startTimer(fiveMinutes, display);
};

</script>

<!-- End of the code of function for displaying timer -->
