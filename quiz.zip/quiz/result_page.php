<div id="usrname"><a href="http://localhost/quiz/user_logout.php">Logout</a></div>
<style>
#usrname{
	margin-left:1100px;
	margin-top:20px;
	font-weight:bold;
	color:green;
	text-transform:uppercase;
}
</style>
<?php 
/* database file included using include function  */

include('db_connect.php');

/* session file included using include function  */

include('session.php');

/* start of the code for displaying the results  */

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$test_type_id = $_SESSION['test_type_id'];

$question_count = "select count(q.id) as quest_cnt from question q inner join user_test_type utt on utt.test_type=q.test_type 
				  where utt.user_id='".$user_id."' and q.test_type='".$test_type_id."'";
				  
$question_result = $conn->query($question_count);


$question_cnt = mysqli_fetch_array($question_result);	

$question_count = $question_cnt['quest_cnt'];


$question_attempt_count = "select count(ans.id) as question_attempt_count from user_answers ans inner join user_test_type utt on 
						   utt.test_type = ans.test_type where ans.user_id='".$user_id."' and ans.test_type='".$test_type_id."'";
$question_attempt_result = $conn->query($question_attempt_count);

$question_attempt_cnt = mysqli_fetch_array($question_attempt_result);	
	
	

$correct_result_qry="select usd.email,count(opt.correct_option) as answers_count from user_details usd left join user_answers usr_ans on usd.id=usr_ans.user_id left join options opt on opt.id=usr_ans.opt_id 
			    left join user_test_type utt on utt.test_type=usr_ans.test_type 
				where usr_ans.user_id='".$user_id."' and usr_ans.test_type='".$test_type_id."' and opt.correct_option='1'";
			 
			 $correct_result = $conn->query($correct_result_qry);

			$correct_cnt = mysqli_fetch_array($correct_result);

		$wrong_count = $question_attempt_cnt['question_attempt_count']-$correct_cnt['answers_count'];
		
		$time_qry = "select test_type,SUBTIME(total_time,time_taken) as remaining_time,test_date from user_test_type where user_id='".$user_id."' and test_type='".$test_type_id."'";
		
		$time_result = $conn->query($time_qry);

			$time_taken = mysqli_fetch_array($time_result);
			
			 $remaining_time = $time_taken['remaining_time'];
			 $test_date  = $time_taken['test_date'];
			 
/* end of the code for displaying the results  */
			 
?>

<!DOCTYPE html>
<html>
<body >

<center><h2>Test Results</h2></center>

<table style="width:50%" border="1" align="center"; bgcolor="lightgreen">
  
  <tr>
    <td><b>User Name</b></td>  <td><?php echo ucwords($user_name); ?></td> 
	</tr>
	<tr>
    <td><b>Email</b></td> <td><?php echo $correct_cnt['email']; ?></td>
	</tr>
	<tr>
    <td><b>Total Questions Given</b></td><td><?php echo $question_count; ?></td>
	</tr>
	<tr>
    <td><b>Total Questions Attempted</b></td><td><?php echo $question_attempt_cnt['question_attempt_count']; ?></td>
	</tr>
	<tr>
	<td><b>Correct Answers</b></td><td><?php echo $correct_cnt['answers_count']; ?></td>
	</tr>
	<tr>
	<td><b>Wrong Answers</b></td><td><?php echo $wrong_count; ?></td>
	</tr>
	<tr>
	<td><b>Test Date</b></td><td><?php echo $test_date; ?></td>
  </tr>
	<tr>
	<td><b>Time Taken (HH:MM:SS)</b></td><td><?php echo $remaining_time; ?></td>
  </tr>
  
</table>

</body>
</html>
